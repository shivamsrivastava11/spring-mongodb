package com.example.SpringMongodb.repository;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.example.SpringMongodb.Model.Book;

public interface BookRepository extends MongoRepository<Book,String> {

	Book findById(int id);

	void deleteById(int id);

	







	
	



}
